/**
 * Профиль пользователя
 *
 * @author  Дмитрий Щербаков <atomcms@ya.ru>
 *
 * @version 24.04.2020
 */

/**
 * Объект страницы
 *
 * @type {object}
 */
var profile = {};