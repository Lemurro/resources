/**
 * Функция обратного вызова после отображения информации
 *
 * @param {Object} data
 *
 * @author  Дмитрий Щербаков <atomcms@ya.ru>
 *
 * @version 24.04.2020
 */
profile._afterShowData = function (data) {

};