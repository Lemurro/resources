/**
 * Изменение записи
 *
 * @author  Дмитрий Щербаков <atomcms@ya.ru>
 *
 * @version 17.04.2020
 */
guideExample.save = function () {
    lemurro.guide.save(guideExample._collectData(), null);
};