/**
 * Добавление записи
 *
 * @author  Дмитрий Щербаков <atomcms@ya.ru>
 *
 * @version 17.04.2020
 */
guideExample.insert = function () {
    lemurro.guide.insert(guideExample._collectData(), null);
};