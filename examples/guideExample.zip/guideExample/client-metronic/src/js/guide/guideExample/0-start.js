/**
 * Справочник: Пример
 *
 * @version 08.04.2019
 * @author  Дмитрий Щербаков <atomcms@ya.ru>
 */

/**
 * Объект страницы
 *
 * @type {object}
 */
var guideExample = {};