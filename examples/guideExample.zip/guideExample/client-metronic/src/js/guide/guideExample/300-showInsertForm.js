/**
 * Покажем форму добавления
 *
 * @version 08.04.2019
 * @author  Дмитрий Щербаков <atomcms@ya.ru>
 */
guideExample.showInsertForm = function () {
    lemurro.guide.showInsertForm(function () {
        // Специфичная очистка формы
    });
};