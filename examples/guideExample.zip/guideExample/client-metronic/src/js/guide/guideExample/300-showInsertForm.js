/**
 * Покажем форму добавления
 *
 * @version 26.10.2018
 * @author  Дмитрий Щербаков <atomcms@ya.ru>
 */
guideExample.showInsertForm = function () {
    lemurro.guide.showInsertForm(function () {
        // Специфичная очистка формы
    });
};