/**
 * Инициализация
 *
 * @version 28.10.2018
 * @author  Дмитрий Щербаков <atomcms@ya.ru>
 */
guideExample.init = function () {

};